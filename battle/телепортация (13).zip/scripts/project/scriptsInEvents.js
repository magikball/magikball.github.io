


const scriptsInEvents = {

	async Eslevels_Event2_Act1(runtime, localVars)
	{
		document.querySelector('body').style['backgroundColor'] = '#3f3851'
	},

	async Esstartmenu_Event1_Act2(runtime, localVars)
	{
		document.querySelector('body').style['backgroundColor'] = '#3f3851'
	}

};

self.C3.ScriptsInEvents = scriptsInEvents;

